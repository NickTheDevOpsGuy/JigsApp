import type { GridSize, Piece, PieceEdges } from "../types";
import { buildPiecePath } from "../shape";

type CreateInitialPiecesArgs = {
  grid: GridSize;
  boardWidth: number;
  boardHeight: number;
  scatterPadding: number;
  pad: number;
  tileW: number;
  tileH: number;
  scatterStartYRatio: number;
  rotationStepDeg: 90 | 180;
  targetStartX: number;
  targetStartY: number;
};

function randInt(min: number, max: number) {
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

function randRotation(rotationStepDeg: 90 | 180): number {
  const steps = 360 / rotationStepDeg;
  const k = randInt(0, steps - 1);
  return (k * rotationStepDeg) % 360;
}

function buildEdgesForGrid(grid: GridSize): PieceEdges[] {
  const edges: PieceEdges[] = [];

  const randomTabOrBlank = (): "tab" | "blank" => (Math.random() < 0.5 ? "tab" : "blank");

  const opposite = (e: PieceEdges["top"]): PieceEdges["top"] => {
    if (e === "flat") return "flat";
    return e === "tab" ? "blank" : "tab";
  };

  for (let r = 0; r < grid.rows; r++) {
    for (let c = 0; c < grid.cols; c++) {
      const top: PieceEdges["top"] =
        r === 0 ? "flat" : opposite(edges[(r - 1) * grid.cols + c].bottom);

      const left: PieceEdges["left"] =
        c === 0 ? "flat" : opposite(edges[r * grid.cols + (c - 1)].right);

      const right: PieceEdges["right"] =
        c === grid.cols - 1 ? "flat" : randomTabOrBlank();
      const bottom: PieceEdges["bottom"] =
        r === grid.rows - 1 ? "flat" : randomTabOrBlank();

      edges.push({ top, right, bottom, left });
    }
  }

  return edges;
}

/**
 * Creates all pieces in their initial scattered positions.
 *
 * This is a pure helper so PuzzleManager stays focused on interaction logic.
 */
export function createInitialPieces(args: CreateInitialPiecesArgs): Piece[] {
  const {
    grid,
    boardWidth,
    boardHeight,
    scatterPadding,
    pad,
    tileW,
    tileH,
    scatterStartYRatio,
    rotationStepDeg,
    targetStartX,
    targetStartY,
  } = args;

  const total = grid.cols * grid.rows;
  const edges = buildEdgesForGrid(grid);

  const w = tileW + pad * 2;
  const h = tileH + pad * 2;

  const scatterStartY = Math.max(
    scatterPadding,
    Math.floor(boardHeight * scatterStartYRatio),
  );

  const scatterZone = {
    minX: scatterPadding,
    maxX: Math.max(scatterPadding + w, boardWidth - scatterPadding),
    minY: scatterStartY,
    maxY: Math.max(scatterStartY + h, boardHeight - scatterPadding),
  };

  const zoneWidth = scatterZone.maxX - scatterZone.minX;
  const zoneHeight = scatterZone.maxY - scatterZone.minY;

  const spacing = 8;
  const cellW = w + spacing;
  const cellH = h + spacing;

  const gridCols = Math.max(1, Math.floor(zoneWidth / cellW));
  const gridRows = Math.max(1, Math.floor(zoneHeight / cellH));

  const positions: Array<{ x: number; y: number }> = [];
  for (let row = 0; row < gridRows; row++) {
    for (let col = 0; col < gridCols; col++) {
      const jitterX = randInt(0, Math.min(spacing * 2, cellW - w));
      const jitterY = randInt(0, Math.min(spacing * 2, cellH - h));

      positions.push({
        x: scatterZone.minX + col * cellW + jitterX,
        y: scatterZone.minY + row * cellH + jitterY,
      });
    }
  }

  // Shuffle positions
  for (let i = positions.length - 1; i > 0; i--) {
    const j = randInt(0, i);
    [positions[i], positions[j]] = [positions[j], positions[i]];
  }

  // If there are fewer cells than pieces, add random positions.
  while (positions.length < total) {
    positions.push({
      x: randInt(scatterZone.minX, Math.max(scatterZone.minX, scatterZone.maxX - w)),
      y: randInt(scatterZone.minY, Math.max(scatterZone.minY, scatterZone.maxY - h)),
    });
  }

  const pieces: Piece[] = [];

  for (let i = 0; i < total; i++) {
    const col = i % grid.cols;
    const row = Math.floor(i / grid.cols);

    const targetX = targetStartX + col * tileW;
    const targetY = targetStartY + row * tileH;

    const pos = positions[i];

    const shapePath = buildPiecePath({
      tileW,
      tileH,
      pad,
      edges: edges[i],
    });

    pieces.push({
      id: `p${i + 1}`,
      row,
      col,
      x: pos.x,
      y: pos.y,
      z: 1,
      w,
      h,
      tileW,
      tileH,
      pad,
      targetX,
      targetY,
      rotation: randRotation(rotationStepDeg),
      targetRotation: 0,
      isPlaced: false,
      groupId: `g${i + 1}`,
      justSnapped: false,
      shapePath,
      edges: edges[i],
      inTray: false,
    });
  }

  return pieces;
}
